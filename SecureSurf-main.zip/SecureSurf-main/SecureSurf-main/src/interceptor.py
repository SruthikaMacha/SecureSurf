# looks for unsafe urls

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWebEngineCore import (
    QWebEngineUrlRequestInterceptor,
    QWebEngineUrlRequestInfo,
)


class SecurityInterceptor(QWebEngineUrlRequestInterceptor):
    # Emitted whenever a request is dropped. reason is "blocklist" or "ai".
    blocked = pyqtSignal(str, str)

    def __init__(self, ad_domains, unsafe_urls, classifier=None):
        super().__init__()
        self.ad_domains = ad_domains
        self.unsafe_urls = unsafe_urls
        self.classifier = classifier

    def interceptRequest(self, info: QWebEngineUrlRequestInfo):
        host = info.requestUrl().host()

        # 1. Fast path — static blocklists (exact host match). Runs on every
        #    request (ads, trackers, malware hosts) and is essentially free.
        if host in self.ad_domains or host in self.unsafe_urls:
            print(f"FIREWALL TRIGGERED: Blocked connection to {host}")
            info.block(True)  # Drops the connection instantly
            self.blocked.emit(host, "blocklist")
            return

        # 2. AI path — only score TOP-LEVEL page navigations, never the dozens
        #    of sub-resources a page pulls. This is what keeps the model
        #    real-time: one prediction per page the user actually visits.
        if self.classifier is not None and self._is_main_frame(info):
            url = info.requestUrl().toString()
            if self.classifier.is_malicious(url, host):
                print(f"AI FIREWALL: Blocked suspicious URL -> {url}")
                info.block(True)
                self.blocked.emit(host, "ai")

    @staticmethod
    def _is_main_frame(info: QWebEngineUrlRequestInfo) -> bool:
        try:
            rt = info.resourceType()
            return rt == QWebEngineUrlRequestInfo.ResourceType.ResourceTypeMainFrame
        except Exception:  # noqa: BLE001 - never let detection break a request
            return False
